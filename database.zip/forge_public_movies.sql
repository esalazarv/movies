insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (1, 'El rey león', 'true', '01:30:30', '2020-12-11', '2020-12-12 00:40:01', '2020-12-12 00:40:01');
insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (2, 'Deadpool', 'true', '01:20:01', '2020-12-11', '2020-12-12 00:41:46', '2020-12-12 00:41:46');
insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (4, 'sdfdsf', 'true', '12:12:12', '2020-12-11', '2020-12-12 00:42:42', '2020-12-12 00:42:42');
insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (5, 'Nuevo', 'true', '01:11:01', '2020-12-11', '2020-12-12 00:44:32', '2020-12-12 00:44:32');
insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (6, 'ewrrwer', 'true', '01:20:00', '2020-12-11', '2020-12-12 00:52:24', '2020-12-12 00:52:24');
insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (3, 'adsdsd', 'true', '12:33:12', '2020-12-11', '2020-12-12 00:42:09', '2020-12-12 23:27:31');
insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (8, 'test', 'true', '02:03:00', '2020-10-10', '2020-12-12 21:51:28', '2020-12-12 23:28:16');
insert into public.movies (id, name, active, duration, publish_date, created_at, updated_at) values (7, 'qwewqe', 'true', '12:31:23', '2020-12-11', '2020-12-12 02:40:38', '2020-12-12 23:28:16');
