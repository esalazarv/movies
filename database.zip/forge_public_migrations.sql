insert into public.migrations (id, migration, batch) values (1, '2014_10_12_000000_create_users_table', 1);
insert into public.migrations (id, migration, batch) values (2, '2014_10_12_100000_create_password_resets_table', 1);
insert into public.migrations (id, migration, batch) values (3, '2019_08_19_000000_create_failed_jobs_table', 1);
insert into public.migrations (id, migration, batch) values (4, '2019_12_14_000001_create_personal_access_tokens_table', 1);
insert into public.migrations (id, migration, batch) values (5, '2020_12_10_172853_create_movies_table', 1);
insert into public.migrations (id, migration, batch) values (6, '2020_12_10_232852_create_schedules_table', 1);
